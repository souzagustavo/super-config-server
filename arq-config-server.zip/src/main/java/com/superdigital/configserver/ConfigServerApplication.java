package com.superdigital.configserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.context.annotation.ComponentScan;

//import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
//import org.springframework.core.env.Environment;


@EnableConfigServer
@SpringBootApplication
@ComponentScan
@EnableAutoConfiguration
public class ConfigServerApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigServerApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(ConfigServerApplication.class, args);
	}

	//@Bean
	//ApplicationRunner applicationRunner(@Value("${password}") String password) {
		//return args -> {
			//LOGGER.info("`password` loaded from the AWS Secret Manager: {}", password);
		//};
	//}

}
